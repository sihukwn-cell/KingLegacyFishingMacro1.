plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.kingpiecefishing"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.kingpiecefishing"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
