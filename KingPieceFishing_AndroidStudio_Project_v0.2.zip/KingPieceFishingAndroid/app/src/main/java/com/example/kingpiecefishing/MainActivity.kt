package com.example.kingpiecefishing

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var startX: EditText
    private lateinit var startY: EditText
    private lateinit var castX: EditText
    private lateinit var castY: EditText
    private lateinit var near100X: EditText
    private lateinit var near100Y: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
        }
        fun label(s: String) { box.addView(TextView(this).apply { text = s; textSize = 15f }) }
        fun field(hint: String, value: String): EditText =
            EditText(this).apply { this.hint = hint; setText(value); inputType = 2 }
        box.addView(TextView(this).apply {
            text = "킹피스 낚시 자동화 · 테스트 빌드"
            textSize = 21f
        })
        label("먼저 접근성 권한을 켜고 화면 캡처 권한을 허용하세요.")
        box.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        label("게임 화면 기준 시작 버튼 좌표 (픽셀)")
        startX = field("시작 X", "1500"); startY = field("시작 Y", "800")
        box.addView(startX); box.addView(startY)
        label("숫자가 100에 가까워졌을 때 터치할 좌표 (픽셀)")
        near100X = field("숫자 단계 터치 X", "1070"); near100Y = field("숫자 단계 터치 Y", "600")
        box.addView(near100X); box.addView(near100Y)
        label("성공 후 다음 숫자 단계로 돌아갈 때 사용할 터치 좌표 (픽셀)")
        castX = field("다음 낚시 X", "1070"); castY = field("다음 낚시 Y", "600")
        box.addView(castX); box.addView(castY)
        label("※ 좌표는 2000×1200 예시값입니다. 태블릿 해상도와 게임 UI에 맞게 조정하세요.")
        box.addView(Button(this).apply {
            text = "화면 감지 및 자동화 시작"
            setOnClickListener { requestCapture() }
        })
        box.addView(Button(this).apply {
            text = "중지"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })
        status = TextView(this).apply { text = "상태: 대기 중"; textSize = 14f }
        box.addView(status)
        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun requestCapture() {
        if (TapAccessibilityService.instance == null) {
            status.text = "상태: 접근성 서비스를 먼저 켜세요."
            return
        }
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        prefs.edit()
            .putFloat("startX", startX.text.toString().toFloatOrNull() ?: 1500f)
            .putFloat("startY", startY.text.toString().toFloatOrNull() ?: 800f)
            .putFloat("castX", castX.text.toString().toFloatOrNull() ?: 1070f)
            .putFloat("castY", castY.text.toString().toFloatOrNull() ?: 600f)
            .putFloat("near100X", near100X.text.toString().toFloatOrNull() ?: 1070f)
            .putFloat("near100Y", near100Y.text.toString().toFloatOrNull() ?: 600f)
            .apply()
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), 41)
    }

    @Deprecated("Legacy result API kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "상태: 화면 감지 시작"
        }
    }
}
