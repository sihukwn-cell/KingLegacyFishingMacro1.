package com.example.kingpiecefishing

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.max

class CaptureService : Service() {
    private enum class Stage { WAIT_NUMBER, WAIT_MINIGAME, PLAY_MINIGAME, WAIT_RETURN }
    private var stage = Stage.WAIT_NUMBER
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var running = false
    private var busy = false
    private var lastTap = 0L
    private var numberTapSent = false
    private var miniGameWasSeen = false
    private var returnTapSent = false
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))
        startCapture()
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channel = "kp_fishing"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(channel, "Fishing automation", NotificationManager.IMPORTANCE_LOW)
        )
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("킹피스 낚시 화면 감지 중")
                .setSmallIcon(android.R.drawable.ic_media_play).build()
        else Notification.Builder(this).setContentTitle("킹피스 낚시 화면 감지 중")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(7, n)
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        thread = HandlerThread("kp-screen-reader").also { it.start() }
        val h = Handler(thread!!.looper)
        display = projection?.createVirtualDisplay(
            "KingPieceCapture", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, h
        )
        running = true
        // First touch starts the fishing sequence, as described by the user.
        Handler(Looper.getMainLooper()).postDelayed({
            if (running && stage == Stage.WAIT_NUMBER && lastTap == 0L) {
                val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
                TapAccessibilityService.instance?.tap(
                    cfg.getFloat("startX", dm.widthPixels * 0.75f),
                    cfg.getFloat("startY", dm.heightPixels * 0.67f),
                    90
                )
                lastTap = System.currentTimeMillis()
            }
        }, 900)
        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try { analyzeFrame(image) } finally { image.close() }
        }, h)
    }

    private fun tapAt(x: Float, y: Float) {
        TapAccessibilityService.instance?.tap(x, y, 90)
        lastTap = System.currentTimeMillis()
    }

    private fun analyzeFrame(image: Image) {
        if (!running || busy) return
        val pl = image.planes[0]
        val paddedWidth = image.width + (pl.rowStride - pl.pixelStride * image.width) / pl.pixelStride
        val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(pl.buffer)
        val frame = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
        full.recycle()

        val now = System.currentTimeMillis()
        when (stage) {
            Stage.WAIT_NUMBER -> {
                // The uploaded 2000x1200 screenshot shows the countdown number
                // around x=53.5%, y=42%; OCR is restricted to that small region.
                busy = true
                val crop = Bitmap.createBitmap(
                    frame,
                    (frame.width * 0.46f).toInt().coerceAtLeast(0),
                    (frame.height * 0.39f).toInt().coerceAtLeast(0),
                    (frame.width * 0.15f).toInt().coerceAtMost(frame.width - (frame.width * 0.46f).toInt()),
                    (frame.height * 0.09f).toInt().coerceAtMost(frame.height - (frame.height * 0.39f).toInt())
                )
                recognizer.process(InputImage.fromBitmap(crop, 0))
                    .addOnSuccessListener { result ->
                        val digits = result.text.filter { it.isDigit() }
                        val value = digits.toIntOrNull()
                        if (stage == Stage.WAIT_NUMBER && value != null && value >= 97 &&
                            now - lastTap > 900 && !numberTapSent) {
                            val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
                            tapAt(cfg.getFloat("near100X", frame.width * 0.535f),
                                  cfg.getFloat("near100Y", frame.height * 0.50f))
                            numberTapSent = true
                            stage = Stage.WAIT_MINIGAME
                        }
                    }
                    .addOnCompleteListener {
                        crop.recycle()
                        frame.recycle()
                        busy = false
                    }
                return
            }
            Stage.WAIT_MINIGAME, Stage.PLAY_MINIGAME -> {
                val y = (frame.height * 0.69f).toInt()
                val x1 = (frame.width * 0.32f).toInt()
                val x2 = (frame.width * 0.68f).toInt()
                val half = max(5, (frame.height * 0.012f).toInt())
                var greenMin = -1
                var greenMax = -1
                var brightPeak = 0
                for (x in x1 until x2) {
                    var greenCount = 0
                    var whiteCount = 0
                    var yy = max(0, y - half)
                    while (yy <= (y + half).coerceAtMost(frame.height - 1)) {
                        val c = frame.getPixel(x, yy)
                        val r = (c shr 16) and 255
                        val g = (c shr 8) and 255
                        val b = c and 255
                        if (g > 105 && g > r * 1.35 && g > b * 1.12) greenCount++
                        if (r > 218 && g > 218 && b > 218) whiteCount++
                        yy += 2
                    }
                    if (greenCount >= 3) {
                        if (greenMin < 0) greenMin = x
                        greenMax = x
                    }
                    if (whiteCount > brightPeak) brightPeak = whiteCount
                }
                val detected = greenMin >= 0 && greenMax - greenMin > frame.width * 0.12f && brightPeak >= 4
                if (detected) {
                    miniGameWasSeen = true
                    stage = Stage.PLAY_MINIGAME
                    // Current image confirms the bar's location, but does not
                    // establish whether touch-down, touch-up, or holding moves
                    // the marker. Do not send guessed continuous controls.
                } else if (stage == Stage.PLAY_MINIGAME && miniGameWasSeen &&
                    now - lastTap > 1200 && !returnTapSent) {
                    // Game mini-game panel disappeared: perform the user's
                    // described one extra touch to return to the number phase.
                    val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
                    tapAt(cfg.getFloat("castX", frame.width * 0.535f),
                          cfg.getFloat("castY", frame.height * 0.50f))
                    returnTapSent = true
                    stage = Stage.WAIT_RETURN
                }
            }
            Stage.WAIT_RETURN -> {
                // Wait for the next numeric fishing phase to become visible.
                busy = true
                val crop = Bitmap.createBitmap(
                    frame,
                    (frame.width * 0.46f).toInt(),
                    (frame.height * 0.39f).toInt(),
                    (frame.width * 0.15f).toInt(),
                    (frame.height * 0.09f).toInt()
                )
                recognizer.process(InputImage.fromBitmap(crop, 0))
                    .addOnSuccessListener { result ->
                        if (result.text.any { it.isDigit() } && stage == Stage.WAIT_RETURN) {
                            stage = Stage.WAIT_NUMBER
                            numberTapSent = false
                            miniGameWasSeen = false
                            returnTapSent = false
                        }
                    }
                    .addOnCompleteListener {
                        crop.recycle()
                        frame.recycle()
                        busy = false
                    }
                return
            }
        }
        frame.recycle()
    }

    override fun onDestroy() {
        running = false
        reader?.close()
        display?.release()
        projection?.stop()
        thread?.quitSafely()
        recognizer.close()
        super.onDestroy()
    }
}
